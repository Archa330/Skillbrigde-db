
const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Sample course data
const courses = [
  {
    id: 1,
    title: "Web Development Fundamentals",
    category: "Development",
    level: "Beginner",
    duration: "6 weeks",
    description:
      "Learn HTML, CSS, JavaScript, and the fundamentals of building websites.",
    icon: "💻",
    color: "#dbeafe",
  },
  {
    id: 2,
    title: "Python Programming",
    category: "Programming",
    level: "Beginner",
    duration: "4 weeks",
    description:
      "Build a strong foundation in Python, problem solving, and programming.",
    icon: "🐍",
    color: "#dcfce7",
  },
  {
    id: 3,
    title: "Data Analytics",
    category: "Data",
    level: "Intermediate",
    duration: "8 weeks",
    description:
      "Explore data analysis, visualization, and data-driven decision making.",
    icon: "📊",
    color: "#fef3c7",
  },
  {
    id: 4,
    title: "UI/UX Design",
    category: "Design",
    level: "Beginner",
    duration: "5 weeks",
    description:
      "Learn design principles, wireframes, prototypes, and user experience.",
    icon: "🎨",
    color: "#f3e8ff",
  },
];

// Home route
app.get("/", (req, res) => {
  res.json({
    message: "Welcome to the SkillBridge API!",
    status: "running",
  });
});

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "OK", message: "Backend is working!" });
});

// Get all courses
app.get("/api/courses", (req, res) => {
  res.json(courses);
});

// Get one course by ID
app.get("/api/courses/:id", (req, res) => {
  const course = courses.find(
    (item) => item.id === Number(req.params.id)
  );

  if (!course) {
    return res.status(404).json({ message: "Course not found" });
  }

  res.json(course);
});

// Handle unknown API routes
app.use("/api", (req, res) => {
  res.status(404).json({ message: "API route not found" });
});

app.listen(PORT, () => {
  console.log(`SkillBridge API running at http://localhost:${PORT}`);
});