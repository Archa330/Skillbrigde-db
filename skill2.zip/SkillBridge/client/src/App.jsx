
import { useEffect, useMemo, useState } from "react";
import "./App.css";

const API_URL = "http://localhost:5000/api";

const categories = [
  "All",
  "Development",
  "Programming",
  "Data",
  "Design",
];

function App() {
  const [courses, setCourses] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [enrolled, setEnrolled] = useState([]);

  useEffect(() => {
    async function loadCourses() {
      try {
        const response = await fetch(`${API_URL}/courses`);

        if (!response.ok) {
          throw new Error("Unable to load courses.");
        }

        const data = await response.json();
        setCourses(data);
      } catch {
        setError(
          "Could not connect to the backend. Make sure your server is running on port 5000."
        );
      } finally {
        setLoading(false);
      }
    }

    loadCourses();
  }, []);

  const filteredCourses = useMemo(() => {
    return courses.filter((course) => {
      const matchesCategory =
        category === "All" || course.category === category;

      const query = search.toLowerCase();
      const matchesSearch =
        course.title.toLowerCase().includes(query) ||
        course.description.toLowerCase().includes(query);

      return matchesCategory && matchesSearch;
    });
  }, [courses, category, search]);

  function toggleEnrollment(courseId) {
    setEnrolled((previous) =>
      previous.includes(courseId)
        ? previous.filter((id) => id !== courseId)
        : [...previous, courseId]
    );
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a href="#home" className="brand">
          <span className="brand-icon">S</span>
          <span>SkillBridge</span>
        </a>

        <p className="nav-label">WORKSPACE</p>

        <a className="nav-link active" href="#home">
          <span>⌂</span> Dashboard
        </a>
        <a className="nav-link" href="#courses">
          <span>▤</span> Explore courses
        </a>
        <a className="nav-link" href="#my-learning">
          <span>◷</span> My learning
        </a>

        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-icon">✦</div>
            <strong>Keep growing!</strong>
            <p>Small steps today, big opportunities tomorrow.</p>
            <a href="#courses">Explore learning →</a>
          </div>
          <div className="profile">
            <div className="avatar">S</div>
            <div>
              <strong>Student</strong>
              <p>Learning account</p>
            </div>
          </div>
        </div>
      </aside>

      <main className="main-content" id="home">
        <header className="topbar">
          <div>
            <span className="eyebrow">YOUR LEARNING SPACE</span>
            <h1>Dashboard</h1>
          </div>
          <a className="topbar-link" href="#courses">
            Discover skills <span>↗</span>
          </a>
        </header>

        <section className="welcome-banner">
          <div className="welcome-copy">
            <span className="banner-tag">YOUR FUTURE STARTS HERE</span>
            <h2>Build skills.<br />Unlock opportunities.</h2>
            <p>
              Learn at your own pace, explore new interests,
              and take the next step in your career.
            </p>
            <a href="#courses" className="primary-button">
              Explore courses <span>→</span>
            </a>
          </div>
          <div className="banner-art" aria-hidden="true">
            <div className="art-circle circle-one" />
            <div className="art-circle circle-two" />
            <div className="art-card">
              <span className="art-sparkle">✦</span>
              <div className="art-book">▤</div>
              <strong>Learn something<br />new every day.</strong>
              <span className="art-progress">
                <i />
              </span>
              <small>Your journey, your pace</small>
            </div>
            <span className="floating-star">✳</span>
          </div>
        </section>

        <section className="stats-grid" aria-label="Learning summary">
          <div className="stat-card">
            <div className="stat-icon purple">▤</div>
            <div>
              <p>Available courses</p>
              <strong>{courses.length}</strong>
              <span>Explore new subjects</span>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon green">✓</div>
            <div>
              <p>My learning</p>
              <strong>{enrolled.length}</strong>
              <span>Courses selected</span>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon orange">✦</div>
            <div>
              <p>Skill categories</p>
              <strong>{Math.max(categories.length - 1, 0)}</strong>
              <span>Areas to explore</span>
            </div>
          </div>
        </section>

        <section className="courses-section" id="courses">
          <div className="section-heading">
            <div>
              <span className="eyebrow">LEARN SOMETHING NEW</span>
              <h2>Explore courses</h2>
              <p>Find the skills that move you forward.</p>
            </div>
            <span className="course-count">
              {filteredCourses.length} courses
            </span>
          </div>

          <div className="course-toolbar">
            <div className="search-box">
              <span>⌕</span>
              <input
                type="search"
                placeholder="Search courses or skills..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                aria-label="Search courses"
              />
            </div>
            <div className="category-list">
              {categories.map((item) => (
                <button
                  key={item}
                  className={`category-chip ${
                    category === item ? "selected" : ""
                  }`}
                  onClick={() => setCategory(item)}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {loading && <p className="notice">Loading courses...</p>}

          {error && (
            <div className="error-notice">
              <strong>Connection problem</strong>
              <p>{error}</p>
              <button onClick={() => window.location.reload()}>
                Try again
              </button>
            </div>
          )}

          {!loading && !error && filteredCourses.length === 0 && (
            <div className="empty-state">
              <span>⌕</span>
              <h3>No courses found</h3>
              <p>Try another search or select a different category.</p>
            </div>
          )}

          <div className="course-grid">
            {filteredCourses.map((course) => (
              <article className="course-card" key={course.id}>
                <div
                  className="course-art"
                  style={{ backgroundColor: course.color }}
                >
                  <span className="course-emoji">{course.icon}</span>
                  <span className="course-level">{course.level}</span>
                </div>

                <div className="course-body">
                  <span className="course-category">{course.category}</span>
                  <h3>{course.title}</h3>
                  <p className="course-description">
                    {course.description}
                  </p>

                  <div className="course-meta">
                    <span>◷ {course.duration}</span>
                    <span>Self-paced</span>
                  </div>

                  <div className="course-actions">
                    <button
                      className="details-button"
                      onClick={() => setSelectedCourse(course)}
                    >
                      View details
                    </button>
                    <button
                      className={`enroll-button ${
                        enrolled.includes(course.id) ? "is-enrolled" : ""
                      }`}
                      onClick={() => toggleEnrollment(course.id)}
                    >
                      {enrolled.includes(course.id)
                        ? "✓ Added"
                        : "Start learning"}
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="learning-panel" id="my-learning">
          <div>
            <span className="eyebrow">YOUR NEXT STEP</span>
            <h2>Make learning a habit.</h2>
            <p>
              {enrolled.length
                ? `You've selected ${enrolled.length} course${enrolled.length === 1 ? "" : "s"}. Keep going!`
                : "Choose a course above to start building your learning plan."}
            </p>
          </div>
          <a href="#courses" className="secondary-button">
            {enrolled.length ? "Continue exploring" : "Find your first course"} →
          </a>
        </section>

        <footer className="footer">
          <a href="#home" className="footer-brand">SkillBridge</a>
          <span>Learn today. Grow tomorrow.</span>
        </footer>
      </main>

      {selectedCourse && (
        <div
          className="modal-backdrop"
          onClick={() => setSelectedCourse(null)}
        >
          <section
            className="course-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              className="modal-close"
              aria-label="Close details"
              onClick={() => setSelectedCourse(null)}
            >
              ×
            </button>
            <div
              className="modal-art"
              style={{ backgroundColor: selectedCourse.color }}
            >
              <span>{selectedCourse.icon}</span>
            </div>
            <span className="course-category">
              {selectedCourse.category}
            </span>
            <h2 id="modal-title">{selectedCourse.title}</h2>
            <p>{selectedCourse.description}</p>
            <div className="modal-meta">
              <span>Level: {selectedCourse.level}</span>
              <span>Duration: {selectedCourse.duration}</span>
            </div>
            <button
              className="enroll-button modal-enroll"
              onClick={() => toggleEnrollment(selectedCourse.id)}
            >
              {enrolled.includes(selectedCourse.id)
                ? "Remove from my learning"
                : "Add to my learning"}
            </button>
          </section>
        </div>
      )}
    </div>
  );
}

export default App;